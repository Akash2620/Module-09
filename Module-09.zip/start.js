require('@babel/register')({});

module.exports = require('./index');